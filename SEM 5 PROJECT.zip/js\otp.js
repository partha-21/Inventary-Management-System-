function sendOTP(user){
  const otp = Math.floor(100000 + Math.random()*900000);
  console.log(`OTP for ${user}: ${otp}`);
  alert(`Demo OTP sent: ${otp} (check console for actual value)`);
  return otp;
}
