document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const orderId = urlParams.get("id");

  if (!orderId) {
    showError();
    return;
  }

  // Fetch order from 'Backend' (api.js)
  const order = apiGetOrder(orderId);

  if (!order) {
    showError();
    return;
  }

  renderOrder(order);
});

function renderOrder(order) {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("orderContent").style.display = "block";

  document.getElementById("dispId").innerText = `#${order.orderId}`;
  document.getElementById("dispDate").innerText = order.date;
  document.getElementById("dispName").innerText = order.customer;
  document.getElementById("dispProduct").innerText = order.product;
  document.getElementById("dispQty").innerText = `${order.qty} Units`;
  document.getElementById("dispTotal").innerText = `₹${order.total.toLocaleString()}`;
}

function showError() {
  document.getElementById("loadingState").style.display = "none";
  document.getElementById("orderContent").style.display = "none";
  document.getElementById("errorState").style.display = "block";
}
