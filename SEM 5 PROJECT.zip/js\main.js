// ============================================
// Auth Logic (Login/Signup)
// ============================================

function loginUser() {
  const userEl = document.getElementById("username");
  const passEl = document.getElementById("password");

  // Guard clause for non-login pages
  if (!userEl || !passEl) return;

  const user = userEl.value;
  const pass = passEl.value;

  if (!user || !pass) { alert("Please enter credentials"); return; }

  if (apiLogin(user, pass)) {
    alert("Login successful! Redirecting...");
    // Simulate session
    localStorage.setItem("ims_current_user", user);
    window.location.href = "products.html";
  } else {
    alert("Invalid username or password.");
  }
}

function createUser() {
  const userEl = document.getElementById("new_username");
  const passEl = document.getElementById("new_password");

  if (!userEl || !passEl) return;

  const user = userEl.value;
  const pass = passEl.value;

  if (!user || !pass) { alert("Please fill all fields"); return; }

  if (apiCreateUser(user, pass)) {
    alert("Account created successfully! Please Login.");
    window.location.href = "login.html";
  } else {
    alert("Username already taken. Try another.");
  }
}

// Redirect if already logged in (optional check for index)
document.addEventListener("DOMContentLoaded", () => {
  const currentUser = localStorage.getItem("ims_current_user");
  // If on index/login/signup and user exists, maybe hint? 
  // For now, we leave it manual as per demo flow.
});
