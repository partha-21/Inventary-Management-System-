let map;

document.addEventListener("DOMContentLoaded", () => {
  // Initialize map centered on India
  map = L.map("map").setView([20.5937, 78.9629], 5);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18 }).addTo(map);

  // 'stores' is now available globally from js/api.js
  const markers = [];
  if (typeof stores !== 'undefined') {
    stores.forEach(s => {
      const marker = L.marker([s.lat, s.lon]).addTo(map).bindPopup(`<b>${s.name}</b>`);
      markers.push(marker);
    });
  }

  // Adjust zoom to fit all markers
  if (markers.length > 0) {
    const group = new L.featureGroup(markers);
    map.fitBounds(group.getBounds());
  }
});

function locateUserPosition() {
  const lat = parseFloat(document.getElementById('latInput').value);
  const lon = parseFloat(document.getElementById('lonInput').value);

  if (isNaN(lat) || isNaN(lon)) {
    alert("Please enter valid Latitude and Longitude values.");
    return;
  }

  // Define custom icon for user location
  const userIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });

  map.setView([lat, lon], 13);
  L.marker([lat, lon], { icon: userIcon }).addTo(map)
    .bindPopup(`<b>Selected Location</b><br>Lat: ${lat}<br>Lon: ${lon}`)
    .openPopup();
}