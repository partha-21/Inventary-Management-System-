// ===================================
// Admin Logic
// ===================================

function adminLogin() {
    const u = document.getElementById("admin_user").value;
    const p = document.getElementById("admin_pass").value;

    if (apiAdminLogin(u, p)) {
        alert("Welcome Admin!");
        localStorage.setItem("ims_admin_current", u);
        window.location.href = "admin_dashboard.html";
    } else {
        alert("Invalid Admin Credentials");
    }
}

function adminSignup() {
    const u = document.getElementById("new_admin_user").value;
    const p = document.getElementById("new_admin_pass").value;

    if (!u || !p) { alert("Fill all fields"); return; }

    if (apiAdminCreate(u, p)) {
        alert("Admin Created. Please Login.");
        window.location.href = "admin_login.html";
    } else {
        alert("Username taken.");
    }
}

function handleAddProduct(e) {
    e.preventDefault();

    const product = {
        name: document.getElementById("prodName").value,
        price: parseFloat(document.getElementById("prodPrice").value),
        category: document.getElementById("prodCat").value,
        supplier: {
            name: document.getElementById("supName").value,
            phone: document.getElementById("supPhone").value,
            email: document.getElementById("supEmail").value,
            store: document.getElementById("storeName").value,
            lat: parseFloat(document.getElementById("locLat").value),
            lon: parseFloat(document.getElementById("locLon").value),
        }
    };

    if (apiAddProduct(product)) {
        alert("Product Added Successfully!");
        e.target.reset();
        updateCount();
    }
}

function updateCount() {
    const el = document.getElementById("totalCount");
    if (el && typeof products !== 'undefined') {
        el.innerText = products.length;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    updateCount();
});
